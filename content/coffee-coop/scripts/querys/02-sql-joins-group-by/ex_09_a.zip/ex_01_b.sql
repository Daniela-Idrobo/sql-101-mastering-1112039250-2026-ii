-- Exercise 01 - b
-- Farms: farm name, rural district, municipality name, first name, and last name for farms in municipality code 54518, ordered by farmer last name

SELECT 
    T1.farm_name AS farm,
    T1.rural_district,
    T2.municipality_name AS municipality,
    T3.first_name,
    T3.last_name
FROM farm.farms T1
INNER JOIN geo.municipalities T2 
    ON T1.municipality_code = T2.municipality_code
INNER JOIN farm.farmers T3 
    ON T1.farmer_id = T3.farmer_id
WHERE T1.municipality_code = '54518'
ORDER BY T3.last_name;

/*
       farm       |    rural_district    | municipality |     first_name     |      last_name
------------------+----------------------+--------------+--------------------+---------------------
 El Jardín        | El Escorial          | Pamplona     | Manuel             | Agudelo Jiménez
 La Selva         | Peñas                | Pamplona     | Manuel             | Agudelo Jiménez
 El Diamante      | El Alizal            | Pamplona     | Marleny            | Agudelo Sandoval
 El Encanto       | Fontibón             | Pamplona     | Rocío              | Álvarez Cárdenas
 Bellavista       | Alto Grande          | Pamplona     | Rocío              | Álvarez Cárdenas
 La Cabaña        | Lengua               | Pamplona     | Mónica             | Álvarez Carrillo
 Monteverde       | Lengua               | Pamplona     | Mónica             | Álvarez Carrillo
 El Arrayán       | Navarro              | Pamplona     | Marleny            | Álvarez Correa
 El Mango         | La Legua             | Pamplona     | Alberto            | Álvarez Villamizar
 Monteverde       | La Legua             | Pamplona     | Myriam Yuliana     | Arango Narváez
(368 filas)
*/