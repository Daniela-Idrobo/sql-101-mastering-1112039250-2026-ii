-- Exercise 10 - a
-- Settlements: settlement code, delivery, net weight kg, price per kg, gross cop, deductions cop, and net cop for settlements on Sept 30, 2026

SELECT
    T1.settlement_id AS settlement,
    T1.delivery_id AS delivery,
    T1.net_weight_kg,
    T1.price_per_kg_applied AS price_per_kg,
    T1.gross_amount AS gross_cop,
    T1.deductions_amount AS deductions_cop,
    T1.net_amount AS net_cop
FROM 
    pay.settlements T1
WHERE 
    T1.settlement_id LIKE '%20260930%';

/*
     settlement      |      delivery       | net_weight_kg | price_per_kg | gross_cop  | deductions_cop |  net_cop
---------------------+---------------------+---------------+--------------+------------+----------------+------------
 STL-20260930-000025 | DLV-20260927-000082 |        180.06 |     22983.00 | 4138318.98 |      182938.77 | 3955380.21
 STL-20260930-000011 | DLV-20260927-000088 |        211.64 |     22841.00 | 4834069.24 |           0.00 | 4834069.24
 STL-20260930-000018 | DLV-20260927-000097 |        216.32 |     21645.00 | 4682246.40 |           0.00 | 4682246.40
 STL-20260930-000002 | DLV-20260927-000104 |        163.44 |     22367.00 | 3655662.48 |      201901.82 | 3453760.66
 STL-20260930-000035 | DLV-20260927-000128 |        237.30 |     22840.00 | 5419932.00 |           0.00 | 5419932.00
 STL-20260930-000027 | DLV-20260927-000144 |        139.52 |     21607.00 | 3014608.64 |           0.00 | 3014608.64
 STL-20260930-000003 | DLV-20260927-000169 |        338.42 |     20409.00 | 6906813.78 |      344352.08 | 6562461.70
 STL-20260930-000007 | DLV-20260927-000177 |        226.45 |     20916.00 | 4736428.20 |      167394.38 | 4569033.82
 STL-20260930-000030 | DLV-20260927-000197 |         39.43 |     23273.00 |  917654.39 |           0.00 |  917654.39
 STL-20260930-000005 | DLV-20260927-000198 |        158.94 |     21608.00 | 3434375.52 |           0.00 | 3434375.52
(69 filas)
*/